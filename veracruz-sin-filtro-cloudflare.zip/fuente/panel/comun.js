// Utilidades del panel
const $ = (s, r = document) => r.querySelector(s);

function el(tag, attrs = {}, ...hijos) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") e.className = v;
    else if (k === "text") e.textContent = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v);
  }
  for (const h of hijos) if (h) e.append(h);
  return e;
}

// De dónde baja el panel cada archivo (requiere sesión)
function fuenteAdmin(m) {
  if (!/^[a-f0-9]{32}$/.test(m.id) || !(m.trozos > 0 && m.trozos < 20)) return { clave: "x", rutas: [], tipo: "", tam: 0 };
  return {
    clave: "a:" + m.id,
    rutas: Array.from({ length: m.trozos }, (_, i) => `/api/medio/${m.id}/${i}`),
    tipo: m.tipo,
    tam: m.tam,
    headers: window.cabecerasAdmin ? window.cabecerasAdmin() : {},
  };
}
const cargarMedio = (m) => descargarMedio(fuenteAdmin(m));

function fmtBytes(b) {
  if (b < 1024 * 1024) return (b / 1024).toFixed(0) + " KB";
  if (b < 1024 ** 3) return (b / 1024 / 1024).toFixed(1) + " MB";
  return (b / 1024 ** 3).toFixed(2) + " GB";
}
