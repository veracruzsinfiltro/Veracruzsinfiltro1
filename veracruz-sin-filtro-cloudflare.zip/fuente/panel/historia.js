// Creador de historias de Instagram (1080x1920) — todo se genera en el navegador del panel
const HW = 1080, HH = 1920;
const H_COLORES = { fondo: "#0b0d10", tarjeta: "#161a20", linea: "#2a303a", texto: "#eef1f5", gris: "#8b93a1", rojo: "#ff4d6d", turquesa: "#22d3c5" };
const H_CUENTA = "@veracruzsinfiltro";
let hEstado = null;

async function hFuentes() {
  try {
    await Promise.all([
      document.fonts.load('400 100px "Anton"'),
      document.fonts.load('700 40px "Inter"'),
      document.fonts.load('400 40px "Inter"'),
    ]);
  } catch {}
}
const F_TITULO = '"Anton", Impact, Haettenschweiler, "Arial Narrow Bold", "Roboto Condensed", sans-serif';
const F_TEXTO = '"Inter", system-ui, -apple-system, sans-serif';

function hRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

// Parte el texto en líneas que caben en el ancho dado
function hLineas(ctx, texto, ancho) {
  const out = [];
  for (const parrafo of texto.split("\n")) {
    let linea = "";
    for (const palabra of parrafo.split(/\s+/).filter(Boolean)) {
      let p = palabra;
      while (ctx.measureText(p).width > ancho) { // palabra larguísima
        let i = p.length;
        while (i > 1 && ctx.measureText(p.slice(0, i)).width > ancho) i--;
        if (linea) { out.push(linea); linea = ""; }
        out.push(p.slice(0, i));
        p = p.slice(i);
      }
      const prueba = linea ? linea + " " + p : p;
      if (ctx.measureText(prueba).width <= ancho) linea = prueba;
      else { out.push(linea); linea = p; }
    }
    out.push(linea);
  }
  while (out.length && !out[out.length - 1]) out.pop();
  return out;
}

// Elige el tamaño de letra más grande que quepa en el alto disponible
function hAjustarTexto(ctx, texto, ancho, altoMax, max, min, peso = 700) {
  for (let t = max; t >= min; t -= 2) {
    ctx.font = `${peso} ${t}px ${F_TEXTO}`;
    const lineas = hLineas(ctx, texto, ancho);
    if (lineas.length * t * 1.3 <= altoMax) return { t, lineas };
  }
  ctx.font = `${peso} ${min}px ${F_TEXTO}`;
  const cabe = Math.max(1, Math.floor(altoMax / (min * 1.3)));
  const lineas = hLineas(ctx, texto, ancho);
  if (lineas.length > cabe) {
    lineas.length = cabe;
    let u = lineas[cabe - 1];
    while (u && ctx.measureText(u + "…").width > ancho) u = u.slice(0, -1);
    lineas[cabe - 1] = u + "…";
  }
  return { t: min, lineas };
}

function hFondo(ctx) {
  ctx.fillStyle = H_COLORES.fondo;
  ctx.fillRect(0, 0, HW, HH);
  const g1 = ctx.createRadialGradient(HW * 0.1, 80, 0, HW * 0.1, 80, 900);
  g1.addColorStop(0, "rgba(255,77,109,.30)"); g1.addColorStop(1, "rgba(255,77,109,0)");
  ctx.fillStyle = g1; ctx.fillRect(0, 0, HW, HH);
  const g2 = ctx.createRadialGradient(HW * 0.95, HH - 60, 0, HW * 0.95, HH - 60, 900);
  g2.addColorStop(0, "rgba(34,211,197,.22)"); g2.addColorStop(1, "rgba(34,211,197,0)");
  ctx.fillStyle = g2; ctx.fillRect(0, 0, HW, HH);
}

function hEncabezado(ctx) {
  // Etiqueta
  ctx.font = `700 30px ${F_TEXTO}`;
  const tag = "CHISME ANÓNIMO";
  const tw = ctx.measureText(tag).width + 60;
  hRect(ctx, (HW - tw) / 2, 150, tw, 58, 29);
  ctx.strokeStyle = "rgba(34,211,197,.5)"; ctx.lineWidth = 2; ctx.stroke();
  ctx.fillStyle = H_COLORES.turquesa; ctx.textAlign = "center"; ctx.textBaseline = "middle";
  ctx.fillText(tag, HW / 2, 180);
  // Logo
  ctx.textBaseline = "alphabetic";
  ctx.font = `400 150px ${F_TITULO}`;
  ctx.fillStyle = H_COLORES.texto;
  ctx.fillText("VERACRUZ", HW / 2, 370);
  ctx.fillStyle = H_COLORES.rojo;
  ctx.fillText("SIN FILTRO", HW / 2, 515);
}

function hPie(ctx) {
  ctx.textAlign = "center"; ctx.textBaseline = "middle";
  ctx.font = `700 40px ${F_TEXTO}`;
  ctx.fillStyle = H_COLORES.texto;
  ctx.fillText(H_CUENTA, HW / 2, 1690);
  ctx.font = `400 32px ${F_TEXTO}`;
  ctx.fillStyle = H_COLORES.gris;
  ctx.fillText("Manda tu chisme anónimo · link en bio", HW / 2, 1745);
}

// Calcula dónde va cada cosa (una sola vez por historia)
function hDiseno(ctx, texto, nombre, medio) {
  const X = 70, AN = HW - 140, Y0 = 575, Y1 = 1610;
  const alto = Y1 - Y0;
  const firma = nombre ? `— ${nombre}` : "";
  const d = { texto: null, medio: null, firma };

  if (!medio) {
    const pad = 70;
    const aj = hAjustarTexto(ctx, texto || "…", AN - pad * 2, alto - pad * 2 - (firma ? 70 : 0) - 60, 76, 38);
    const h = aj.lineas.length * aj.t * 1.3 + pad * 2 + (firma ? 70 : 0) + 60;
    d.texto = { x: X, y: Y0 + (alto - h) / 2, w: AN, h, pad, ...aj, grande: true };
    return d;
  }

  let altoTexto = 0;
  if (texto) {
    const pad = 40;
    const aj = hAjustarTexto(ctx, texto, AN - pad * 2, 380 - (firma ? 50 : 0), 46, 30);
    altoTexto = aj.lineas.length * aj.t * 1.3 + pad * 2 + (firma ? 50 : 0);
    d.texto = { x: X, w: AN, h: altoTexto, pad, ...aj, grande: false };
  }
  const sep = texto ? 30 : 0;
  const altoMedio = alto - altoTexto - sep;
  const k = Math.min(AN / medio.w, altoMedio / medio.h);
  const mw = medio.w * k, mh = medio.h * k;
  const bloque = mh + sep + altoTexto;
  const yM = Y0 + (alto - bloque) / 2;
  d.medio = { x: (HW - mw) / 2, y: yM, w: mw, h: mh };
  if (d.texto) d.texto.y = yM + mh + sep;
  return d;
}

function hDibujar(ctx, d, fuente) {
  hFondo(ctx);
  hEncabezado(ctx);
  if (d.medio && fuente) {
    const m = d.medio;
    ctx.save();
    ctx.shadowColor = "rgba(0,0,0,.6)"; ctx.shadowBlur = 40; ctx.shadowOffsetY = 12;
    hRect(ctx, m.x, m.y, m.w, m.h, 36); ctx.fillStyle = "#000"; ctx.fill();
    ctx.restore();
    ctx.save();
    hRect(ctx, m.x, m.y, m.w, m.h, 36); ctx.clip();
    ctx.drawImage(fuente, m.x, m.y, m.w, m.h);
    ctx.restore();
  }
  if (d.texto) {
    const t = d.texto;
    hRect(ctx, t.x, t.y, t.w, t.h, 36);
    ctx.fillStyle = H_COLORES.tarjeta; ctx.fill();
    ctx.strokeStyle = H_COLORES.linea; ctx.lineWidth = 2; ctx.stroke();
    ctx.textAlign = "left"; ctx.textBaseline = "top";
    let y = t.y + t.pad;
    if (t.grande) {
      ctx.fillStyle = H_COLORES.rojo;
      ctx.font = `400 120px ${F_TITULO}`;
      ctx.fillText("“", t.x + t.pad - 6, t.y + 20);
      y += 60;
    }
    ctx.fillStyle = H_COLORES.texto;
    ctx.font = `700 ${t.t}px ${F_TEXTO}`;
    for (const l of t.lineas) { ctx.fillText(l, t.x + t.pad, y); y += t.t * 1.3; }
    if (d.firma) {
      ctx.fillStyle = H_COLORES.gris;
      ctx.font = `400 ${t.grande ? 36 : 30}px ${F_TEXTO}`;
      ctx.fillText(d.firma, t.x + t.pad, y + (t.grande ? 24 : 14));
    }
  }
  hPie(ctx);
}

// ---------- Generar ----------
async function hGenerarImagen(cv, texto, nombre, fuente, dims) {
  const ctx = cv.getContext("2d");
  const d = hDiseno(ctx, texto, nombre, dims);
  hDibujar(ctx, d, fuente);
  const blob = await new Promise((r) => cv.toBlob(r, "image/jpeg", 0.93));
  return new File([blob], `historia-vsf-${Date.now()}.jpg`, { type: "image/jpeg" });
}

function hFormatoVideo() {
  const ops = [
    "video/mp4;codecs=avc1.42E01F,mp4a.40.2",
    "video/mp4;codecs=avc1,mp4a",
    "video/mp4",
    "video/webm;codecs=vp9,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm",
  ];
  return ops.find((t) => window.MediaRecorder && MediaRecorder.isTypeSupported(t)) || "";
}

async function hGenerarVideo(cv, texto, nombre, video, alAvanzar, senal) {
  const ctx = cv.getContext("2d");
  const d = hDiseno(ctx, texto, nombre, { w: video.videoWidth, h: video.videoHeight });
  const tipo = hFormatoVideo();
  if (!tipo) throw new Error("Este navegador no puede crear videos. Usa Chrome o Safari actualizado.");

  const flujo = cv.captureStream(30);
  // El audio del video se manda a la grabación (no a las bocinas). Se crea una sola vez por video.
  try {
    if (!video._audio) {
      const actx = new (window.AudioContext || window.webkitAudioContext)();
      const destino = actx.createMediaStreamDestination();
      actx.createMediaElementSource(video).connect(destino);
      video._audio = { actx, destino };
    }
    await video._audio.actx.resume();
    video._audio.destino.stream.getAudioTracks().forEach((t) => flujo.addTrack(t));
  } catch {}

  const rec = new MediaRecorder(flujo, { mimeType: tipo, videoBitsPerSecond: 8_000_000 });
  const partes = [];
  rec.ondataavailable = (e) => e.data.size && partes.push(e.data);
  const fin = new Promise((r) => (rec.onstop = r));

  const limite = Math.min(video.duration || 60, 60); // las historias duran máx. 60 s
  video.currentTime = 0;
  video.muted = false;
  await new Promise((r) => (video.onseeked = r, setTimeout(r, 500)));

  let corriendo = true;
  const cuadro = () => {
    if (!corriendo) return;
    hDibujar(ctx, d, video);
    alAvanzar(Math.min(1, video.currentTime / limite));
    if (video.currentTime >= limite || video.ended || senal.cancelado) {
      corriendo = false; video.pause(); rec.stop(); return;
    }
    video.requestVideoFrameCallback ? video.requestVideoFrameCallback(cuadro) : requestAnimationFrame(cuadro);
  };
  hDibujar(ctx, d, video);
  rec.start(500);
  try { await video.play(); }
  catch { video.muted = true; await video.play(); } // si el navegador no deja sonido, se graba sin audio
  cuadro();
  video.onended = () => { if (corriendo) { corriendo = false; rec.stop(); } };
  await fin;
  flujo.getVideoTracks().forEach((t) => t.stop());
  if (senal.cancelado) throw new Error("cancelado");
  const ext = tipo.includes("mp4") ? "mp4" : "webm";
  const base = tipo.split(";")[0];
  return new File([new Blob(partes, { type: base })], `historia-vsf-${Date.now()}.${ext}`, { type: base });
}

// ---------- Ventana del editor ----------
function hCerrar() {
  if (hEstado) {
    hEstado.senal.cancelado = true;
    if (hEstado.video) hEstado.video.pause();
    if (hEstado.url) URL.revokeObjectURL(hEstado.url);
  }
  hEstado = null;
  $("#historia").classList.add("oculto");
  document.body.classList.remove("sin-scroll");
}

async function hCargarFuente(m) {
  const src = await cargarMedio(m);
  if (m.tipo.startsWith("video/")) {
    const v = document.createElement("video");
    v.playsInline = true; v.preload = "auto"; v.src = src;
    await new Promise((ok, mal) => { v.onloadeddata = ok; v.onerror = mal; });
    return { el: v, w: v.videoWidth, h: v.videoHeight, video: true };
  }
  const i = new Image(); i.src = src;
  await i.decode();
  return { el: i, w: i.naturalWidth, h: i.naturalHeight, video: false };
}

async function hVistaPrevia() {
  const e = hEstado; if (!e) return;
  const cv = $("#h-lienzo");
  const texto = $("#h-texto").value.trim();
  const nombre = $("#h-nombre").checked ? (e.chisme.nombre || "") : "";
  const f = e.fuente;
  const ctx = cv.getContext("2d");
  const d = hDiseno(ctx, texto, nombre, f ? { w: f.w, h: f.h } : null);
  hDibujar(ctx, d, f ? f.el : null);
  e.archivo = null;
  $("#h-compartir").disabled = true;
  $("#h-descargar").disabled = true;
}

async function abrirHistoria(c) {
  await hFuentes();
  hEstado = { chisme: c, fuente: null, archivo: null, senal: { cancelado: false } };
  $("#h-texto").value = c.publicacion ? c.publicacion.texto : (c.texto || "");
  $("#h-nombre").checked = !!(c.publicacion && c.publicacion.mostrarNombre);
  $("#h-nombre-fila").classList.toggle("oculto", !c.nombre);
  const sel = $("#h-medio"); sel.textContent = "";
  sel.append(el("option", { value: "-1", text: "Sin foto/video" }));
  (c.medios || []).forEach((m, i) =>
    sel.append(el("option", { value: String(i), text: `${m.tipo.startsWith("video/") ? "Video" : "Foto"} ${i + 1}` })));
  sel.value = c.medios && c.medios.length ? "0" : "-1";
  $("#h-estado").textContent = "";
  $("#h-barra").style.width = "0";
  $("#historia").classList.remove("oculto");
  document.body.classList.add("sin-scroll");
  await hCambiarMedio();
}

async function hCambiarMedio() {
  const e = hEstado; if (!e) return;
  const i = Number($("#h-medio").value);
  e.fuente = null;
  if (i >= 0) {
    $("#h-estado").textContent = "Cargando archivo…";
    try { e.fuente = await hCargarFuente(e.chisme.medios[i]); $("#h-estado").textContent = ""; }
    catch { $("#h-estado").textContent = "No se pudo cargar el archivo"; }
  }
  $("#h-generar").textContent = e.fuente && e.fuente.video ? "Crear historia (video)" : "Crear historia";
  hVistaPrevia();
}

async function hGenerar() {
  const e = hEstado; if (!e) return;
  const btn = $("#h-generar");
  btn.disabled = true;
  const texto = $("#h-texto").value.trim();
  const nombre = $("#h-nombre").checked ? (e.chisme.nombre || "") : "";
  const cv = $("#h-lienzo");
  try {
    if (e.fuente && e.fuente.video) {
      $("#h-estado").textContent = "Grabando el video… deja la pantalla encendida y esta pestaña abierta.";
      e.archivo = await hGenerarVideo(cv, texto, nombre, e.fuente.el, (p) => {
        $("#h-barra").style.width = Math.round(p * 100) + "%";
      }, e.senal);
    } else {
      e.archivo = await hGenerarImagen(cv, texto, nombre, e.fuente && e.fuente.el, e.fuente && { w: e.fuente.w, h: e.fuente.h });
    }
    if (e !== hEstado) return;
    $("#h-barra").style.width = "100%";
    const puede = navigator.canShare && navigator.canShare({ files: [e.archivo] });
    const aviso = e.archivo.type === "video/webm"
      ? " Ojo: este navegador lo creó en WEBM; si Instagram no lo acepta, créalo desde Safari o Chrome actualizado."
      : "";
    $("#h-estado").textContent = (puede
      ? "¡Lista! Toca «Compartir en Instagram» y elige Instagram → Historia."
      : "¡Lista! Descárgala y súbela desde Instagram.") + aviso;
    $("#h-compartir").disabled = !puede;
    $("#h-descargar").disabled = false;
  } catch (err) {
    if (err.message !== "cancelado") $("#h-estado").textContent = err.message || "No se pudo crear la historia";
  } finally {
    btn.disabled = false;
  }
}

async function hCompartir() {
  const e = hEstado; if (!e || !e.archivo) return;
  try {
    await navigator.share({ files: [e.archivo] });
    $("#h-estado").textContent = "Enviada. Cuando la publiques, márcalo como «Ya lo subí a IG».";
  } catch (err) {
    if (err.name !== "AbortError") $("#h-estado").textContent = "No se pudo abrir compartir. Usa «Descargar».";
  }
}

function hDescargar() {
  const e = hEstado; if (!e || !e.archivo) return;
  if (e.url) URL.revokeObjectURL(e.url);
  e.url = URL.createObjectURL(e.archivo);
  const a = el("a", { href: e.url, download: e.archivo.name });
  document.body.append(a); a.click(); a.remove();
}

let hTemporizador = null;
$("#h-texto").addEventListener("input", () => { clearTimeout(hTemporizador); hTemporizador = setTimeout(hVistaPrevia, 250); });
$("#h-nombre").addEventListener("change", hVistaPrevia);
$("#h-medio").addEventListener("change", hCambiarMedio);
$("#h-generar").addEventListener("click", hGenerar);
$("#h-compartir").addEventListener("click", hCompartir);
$("#h-descargar").addEventListener("click", hDescargar);
$("#h-cerrar").addEventListener("click", hCerrar);
document.addEventListener("keydown", (ev) => { if (ev.key === "Escape" && hEstado) hCerrar(); });
