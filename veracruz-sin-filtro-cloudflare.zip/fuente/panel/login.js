// Pantalla de acceso. El código del panel NO es público: solo se descarga con sesión válida.
const CLAVE = "vsf_admin";
const base = location.pathname.replace(/\/+$/, "");
const q = (s) => document.querySelector(s);
const leer = () => { try { return sessionStorage.getItem(CLAVE); } catch { return null; } };
const borrar = () => { try { sessionStorage.removeItem(CLAVE); } catch {} };
const recargar = () => location.replace(base);

async function abrirPanel(token) {
  const r = await fetch("/api/admin/llave-codigo", { headers: { authorization: "Bearer " + token } }).catch(() => null);
  if (!r || !r.ok) { borrar(); return false; }
  const { llave } = await r.json().catch(() => ({}));
  if (typeof llave !== "string") { borrar(); return false; }
  q("#acceso").remove();
  const s = document.createElement("script");
  s.src = `${base}/p.js?k=${encodeURIComponent(llave)}`;
  s.onerror = () => { borrar(); recargar(); };
  document.body.append(s);
  return true;
}

let captcha = null;
const boton = () => q("#acceso button");
function prepararCaptcha() {
  boton().disabled = true;
  boton().textContent = "Verificando…";
  resolverReto("login")
    .then((c) => { captcha = c; boton().disabled = false; boton().textContent = "Entrar"; })
    .catch(() => { boton().textContent = "Recarga la página"; });
}

let enviando = false;
q("#acceso").addEventListener("submit", async (e) => {
  e.preventDefault();
  if (enviando || !captcha) return; // evita doble clic
  enviando = true;
  boton().disabled = true;
  if (q("#w").value) return recargar(); // campo trampa: bots
  const r = await fetch("/api/entrar", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ usuario: q("#u").value, clave: q("#p").value, reto: captcha.reto, nonce: captcha.nonce }),
  }).catch(() => null);
  q("#p").value = "";
  if (!r || !r.ok) return recargar(); // sin mensajes: solo recarga
  const { token } = await r.json().catch(() => ({}));
  if (typeof token !== "string") return recargar();
  try { sessionStorage.setItem(CLAVE, token); } catch {}
  if (!(await abrirPanel(token))) recargar();
});

(async () => {
  const t = leer();
  if (t && (await abrirPanel(t))) return;
  q("#acceso").classList.remove("oculto");
  q("#u").focus();
  prepararCaptcha();
})();
