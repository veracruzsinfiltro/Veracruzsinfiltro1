const CLAVE_SESION = "vsf_admin";
let token = null;
try { token = sessionStorage.getItem(CLAVE_SESION); } catch {}
window.cabecerasAdmin = () => ({ authorization: "Bearer " + token });

const api = (ruta, opts = {}) =>
  fetch(ruta, { ...opts, headers: { ...(opts.headers || {}), authorization: "Bearer " + token } })
    .then((r) => { if (r.status === 401) { mostrarLogin(); throw new Error("sesion"); } return r; });
const apiJSON = (ruta, metodo, cuerpo) =>
  api(ruta, { method: metodo, headers: { "content-type": "application/json" }, body: JSON.stringify(cuerpo) });

function mostrarLogin() {
  try { sessionStorage.removeItem(CLAVE_SESION); } catch {}
  location.replace(location.pathname);
}

// ---------- estado ----------
// fila del índice: [llave, hora, fotos, videos, conNombre, subidoIG, enPagina]
let indice = [];
let filtrados = [];
let mostrados = 0;
let busqueda = null; // Set de llaves o null
const filtro = { estado: "pendientes", tipo: "todos" };
const POR_PAGINA = 15;
const cache = new Map(); // llave → chisme descifrado

const K = 0, T = 1, F = 2, V = 3, N = 4, IG = 5, AP = 6;
const fila = (k) => indice.find((r) => r[K] === k);

// ---------- índice y estadísticas ----------
async function cargarIndice(intento = 0) {
  const aviso = $("#aviso-panel");
  let d;
  try {
    const r = await api("/api/admin/indice");
    if (!r.ok) throw new Error("http " + r.status);
    d = await r.json();
  } catch (e) {
    if (e.message === "sesion") return;
    aviso.textContent = "No se pudo cargar. Reintentando…";
    aviso.classList.remove("oculto");
    if (intento < 20) setTimeout(() => cargarIndice(intento + 1), 2000);
    return;
  }
  indice = Array.isArray(d.idx) ? d.idx : [];
  pintarStats();
  aplicarFiltros();
  if (d.pendientes > 0) {
    aviso.textContent = `Actualizando chismes antiguos al nuevo formato… faltan ${d.pendientes}. No cierres el panel.`;
    aviso.classList.remove("oculto");
    setTimeout(() => cargarIndice(0), 1200);
  } else {
    aviso.classList.add("oculto");
  }
}

function pintarStats() {
  const hoy = new Date(); hoy.setHours(0, 0, 0, 0);
  const dias = [];
  for (let d = 13; d >= 0; d--) {
    const ini = new Date(hoy); ini.setDate(hoy.getDate() - d);
    const fin = new Date(ini); fin.setDate(ini.getDate() + 1);
    dias.push({ ini, n: 0, a: +ini, b: +fin });
  }
  let fotos = 0, videos = 0, nombre = 0, pend = 0, pagina = 0, conFoto = 0, conVideo = 0;
  for (const r of indice) {
    fotos += r[F]; videos += r[V]; nombre += r[N];
    if (r[F]) conFoto++;
    if (r[V]) conVideo++;
    if (!r[IG]) pend++;
    if (r[AP]) pagina++;
    for (const d of dias) if (r[T] >= d.a && r[T] < d.b) { d.n++; break; }
  }
  const fmt = (n) => n.toLocaleString("es-MX");
  $("#s-total").textContent = fmt(indice.length);
  $("#s-hoy").textContent = fmt(dias[13].n);
  $("#s-fotos").textContent = fmt(fotos);
  $("#s-videos").textContent = fmt(videos);
  $("#s-nombre").textContent = fmt(nombre);
  $("#s-pend").textContent = fmt(pend);
  $("#s-pagina").textContent = fmt(pagina);
  $("#s-semana").textContent = fmt(dias.slice(7).reduce((a, d) => a + d.n, 0));
  $("#c-pendientes").textContent = fmt(pend);
  $("#c-ig").textContent = fmt(indice.length - pend);
  $("#c-pagina").textContent = fmt(pagina);
  $("#c-sinpagina").textContent = fmt(indice.length - pagina);
  $("#c-todos").textContent = fmt(indice.length);
  $("#c-fotos").textContent = fmt(conFoto);
  $("#c-videos").textContent = fmt(conVideo);

  const max = Math.max(1, ...dias.map((d) => d.n));
  const g = $("#grafica"); g.textContent = "";
  for (const d of dias) {
    const b = el("div", { class: "b" }); b.style.height = (d.n / max) * 100 + "%";
    g.append(el("div", { class: "col", title: `${d.n} chismes` },
      el("em", { text: d.n || "" }), b,
      el("span", { text: d.ini.toLocaleDateString("es-MX", { day: "numeric" }) })));
  }
}

// ---------- filtros y lista ----------
function pasa(r) {
  const e = filtro.estado;
  if (e === "pendientes" && r[IG]) return false;
  if (e === "ig" && !r[IG]) return false;
  if (e === "pagina" && !r[AP]) return false;
  if (e === "sinpagina" && r[AP]) return false;
  if (filtro.tipo === "fotos" && !r[F]) return false;
  if (filtro.tipo === "videos" && !r[V]) return false;
  if (busqueda && !busqueda.has(r[K])) return false;
  return true;
}

function aplicarFiltros() {
  filtrados = indice.filter(pasa).map((r) => r[K]);
  mostrados = 0;
  $("#lista").textContent = "";
  $("#resultado").textContent = `${filtrados.length.toLocaleString("es-MX")} chismes`;
  cargarMas();
}

let cargando = false;
async function cargarMas() {
  if (cargando) return;
  const pagina = filtrados.slice(mostrados, mostrados + POR_PAGINA);
  if (!pagina.length) {
    if (!mostrados) $("#lista").append(el("div", { class: "vacio", text: "Nada por aquí." }));
    $("#mas").classList.add("oculto");
    return;
  }
  cargando = true;
  const version = filtrados;
  $("#mas").disabled = true;
  try {
    const faltan = pagina.filter((k) => !cache.has(k));
    if (faltan.length) {
      const r = await apiJSON("/api/admin/leer", "POST", { llaves: faltan });
      const d = await r.json();
      for (const c of d.items || []) cache.set(c.id, c);
    }
    if (version !== filtrados) return; // cambió el filtro mientras cargaba
    for (const k of pagina) {
      const c = cache.get(k);
      if (c) $("#lista").append(tarjeta(c));
    }
    mostrados += pagina.length;
  } catch {} finally {
    cargando = false;
    $("#mas").disabled = false;
    $("#mas").classList.toggle("oculto", mostrados >= filtrados.length);
  }
}

function tarjeta(c) {
  const r = fila(c.id) || [];
  const acciones = el("div", { class: "acciones" });
  const boton = (texto, clase, fn) => acciones.append(el("button", { class: "btn chico " + clase, type: "button", text: texto, onclick: fn }));

  boton(r[AP] ? "Editar en la página" : "Publicar en la página", "ok", () => abrirEditor(c));
  boton("Crear historia", "ig", () => { if (!hEstado) abrirHistoria(c); });
  if (c.texto) boton("Copiar texto", "sec", async (ev) => {
    try { await navigator.clipboard.writeText(c.texto); ev.target.textContent = "Copiado ✓"; }
    catch { ev.target.textContent = "No se pudo copiar"; }
  });
  if (c.medios && c.medios.length) boton(c.medios.length > 1 ? `Descargar ${c.medios.length}` : "Descargar", "sec", (ev) => descargar(c, ev.target));
  boton(r[IG] ? "Marcar pendiente IG" : "Ya lo subí a IG ✓", "sec", async (ev) => {
    ev.target.disabled = true;
    await apiJSON(`/api/admin/estado/${c.id}`, "PUT", { publicado: !r[IG] }).catch(() => {});
    r[IG] = r[IG] ? 0 : 1;
    refrescar(c, ev.target);
  });
  boton("Eliminar", "peligro", async (ev) => {
    if (!confirm("¿Eliminar este chisme y sus archivos? También se quita de la página. No se puede deshacer.")) return;
    ev.target.disabled = true;
    await api(`/api/admin/chismes/${c.id}`, { method: "DELETE" }).catch(() => {});
    indice = indice.filter((x) => x[K] !== c.id);
    filtrados = filtrados.filter((k) => k !== c.id);
    mostrados = Math.max(0, mostrados - 1);
    cache.delete(c.id);
    ev.target.closest("article").remove();
    pintarStats();
  });

  const etiquetas = el("div", { class: "etiquetas" });
  if (r[AP]) etiquetas.append(el("span", { class: "etq verde", text: "En la página" }));
  if (r[IG]) etiquetas.append(el("span", { class: "etq", text: "Subido a IG" }));
  const pie = el("div", {},
    el("div", { class: "contar fecha", text: new Date(c.t).toLocaleString("es-MX") }),
    etiquetas, acciones);
  const card = tarjetaChisme(c, fuenteAdmin, pie);
  card.dataset.id = c.id;
  if (r[IG]) card.classList.add("publicado");
  return card;
}

// Vuelve a pintar solo una tarjeta (sin recargar la lista)
function refrescar(c, dentro) {
  const vieja = dentro && dentro.closest("article");
  pintarStats();
  const r = fila(c.id);
  if (!vieja) return;
  if (r && pasa(r)) vieja.replaceWith(tarjeta(c));
  else {
    vieja.remove();
    filtrados = filtrados.filter((k) => k !== c.id);
    mostrados = Math.max(0, mostrados - 1);
  }
}

// ---------- editor de publicación ----------
let edicion = null;
function abrirEditor(c) {
  const r = fila(c.id);
  const pub = c.publicacion;
  edicion = { c, boton: null };
  $("#e-texto").value = pub ? pub.texto : (c.texto || "");
  $("#e-nombre").checked = pub ? pub.mostrarNombre : false;
  $("#e-nombre-fila").classList.toggle("oculto", !c.nombre);
  $("#e-nombre-txt").textContent = c.nombre ? `Mostrar quién lo subió (“${c.nombre}”)` : "";
  const cont = $("#e-medios"); cont.textContent = "";
  (c.medios || []).forEach((m, i) => {
    const marcado = pub ? pub.medios.includes(i) : true;
    const chk = el("input", { type: "checkbox", value: String(i) });
    chk.checked = marcado;
    cont.append(el("label", { class: "check" }, chk,
      document.createTextNode(`${m.tipo.startsWith("video/") ? "Video" : "Foto"} ${i + 1} · ${fmtBytes(m.tam)}`)));
  });
  $("#e-medios-fila").classList.toggle("oculto", !(c.medios || []).length);
  $("#e-publicar").textContent = r && r[AP] ? "Guardar cambios" : "Publicar en la página";
  $("#e-quitar").classList.toggle("oculto", !(r && r[AP]));
  $("#e-estado").textContent = "";
  $("#editor").classList.remove("oculto");
  document.body.classList.add("sin-scroll");
}

function cerrarEditor() {
  $("#editor").classList.add("oculto");
  document.body.classList.remove("sin-scroll");
  edicion = null;
}

function tarjetaEnLista(id) {
  for (const a of document.querySelectorAll("#lista article")) if (a.dataset.id === id) return a;
  return null;
}

let guardando = false;
async function guardarPublicacion(quitar) {
  if (!edicion || guardando) return;
  guardando = true;
  $("#e-publicar").disabled = true;
  $("#e-quitar").disabled = true;
  try { await guardarPublicacionReal(quitar); }
  finally {
    guardando = false;
    $("#e-publicar").disabled = false;
    $("#e-quitar").disabled = false;
  }
}

async function guardarPublicacionReal(quitar) {
  const { c } = edicion;
  const r = fila(c.id);
  const estado = $("#e-estado");
  estado.textContent = "Guardando…";
  try {
    if (quitar) {
      if (!confirm("¿Quitar este chisme de la página?")) { estado.textContent = ""; return; }
      await api(`/api/admin/muro/${c.id}`, { method: "DELETE" });
      c.publicacion = null;
      if (r) r[AP] = 0;
    } else {
      const medios = [...document.querySelectorAll("#e-medios input:checked")].map((x) => Number(x.value));
      const texto = $("#e-texto").value.trim();
      const mostrarNombre = $("#e-nombre").checked && !!c.nombre;
      const resp = await apiJSON(`/api/admin/muro/${c.id}`, "PUT", { texto, mostrarNombre, medios });
      const d = await resp.json().catch(() => ({}));
      if (!resp.ok) { estado.textContent = d.error || "No se pudo guardar"; return; }
      c.publicacion = { texto, mostrarNombre, medios };
      if (r) r[AP] = 1;
    }
    const vieja = tarjetaEnLista(c.id);
    cerrarEditor();
    if (vieja) refrescar(c, vieja.querySelector("button"));
    else pintarStats();
  } catch { estado.textContent = "No se pudo guardar"; }
}

// ---------- descargas ----------
const EXT = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp", "image/gif": "gif",
  "video/mp4": "mp4", "video/webm": "webm", "video/quicktime": "mov" };

// Vuelve a dibujar la foto desde cero: el archivo descargado es una imagen limpia
async function reimprimir(src) {
  const img = await new Promise((ok, mal) => { const i = new Image(); i.onload = () => ok(i); i.onerror = mal; i.src = src; });
  const cv = document.createElement("canvas");
  cv.width = img.naturalWidth; cv.height = img.naturalHeight;
  cv.getContext("2d").drawImage(img, 0, 0);
  const blob = await new Promise((r) => cv.toBlob(r, "image/jpeg", 0.95));
  if (!blob) throw new Error("imagen");
  return URL.createObjectURL(blob);
}

async function descargar(c, boton) {
  const original = boton.textContent;
  boton.disabled = true; boton.textContent = "Descargando…";
  try {
    for (let i = 0; i < c.medios.length; i++) {
      const m = c.medios[i];
      let src = await cargarMedio(m);
      let ext = EXT[m.tipo] || "bin";
      if (/^image\/(jpeg|png|webp)$/.test(m.tipo)) { src = await reimprimir(src); ext = "jpg"; }
      const a = el("a", { href: src, download: `chisme-${c.id.slice(-9, -4)}-${i + 1}.${ext}` });
      document.body.append(a); a.click(); a.remove();
      await new Promise((r) => setTimeout(r, 400));
    }
    boton.textContent = "Descargado ✓";
  } catch { boton.textContent = original; }
  boton.disabled = false;
}

// ---------- eventos ----------
$("#salir").addEventListener("click", mostrarLogin);
$("#refrescar").addEventListener("click", () => { cache.clear(); cargarIndice().catch(() => {}); });
$("#mas").addEventListener("click", cargarMas);
document.querySelectorAll("[data-estado]").forEach((b) => b.addEventListener("click", () => {
  filtro.estado = b.dataset.estado;
  document.querySelectorAll("[data-estado]").forEach((x) => x.classList.toggle("activo", x === b));
  aplicarFiltros();
}));
document.querySelectorAll("[data-tipo]").forEach((b) => b.addEventListener("click", () => {
  filtro.tipo = b.dataset.tipo;
  document.querySelectorAll("[data-tipo]").forEach((x) => x.classList.toggle("activo", x === b));
  aplicarFiltros();
}));

let tBuscar = null, nBuscar = 0;
$("#buscar").addEventListener("input", () => {
  clearTimeout(tBuscar);
  tBuscar = setTimeout(async () => {
    const q = $("#buscar").value.trim();
    const yo = ++nBuscar;
    if (q.length < 2) { busqueda = null; aplicarFiltros(); return; }
    $("#resultado").textContent = "Buscando…";
    try {
      const r = await apiJSON("/api/admin/buscar", "POST", { q, llaves: indice.map((x) => x[K]) });
      const d = await r.json();
      if (yo !== nBuscar) return;
      busqueda = new Set(d.llaves || []);
      if (d.incompleta) $("#aviso-panel").textContent = "Búsqueda parcial: afina la palabra para buscar en todo.";
      aplicarFiltros();
    } catch {}
  }, 450);
});

$("#e-publicar").addEventListener("click", () => guardarPublicacion(false));
$("#e-quitar").addEventListener("click", () => guardarPublicacion(true));
$("#e-cerrar").addEventListener("click", cerrarEditor);
document.addEventListener("keydown", (ev) => { if (ev.key === "Escape" && edicion) cerrarEditor(); });

// Carga infinita: al llegar abajo se cargan más
if ("IntersectionObserver" in window) {
  new IntersectionObserver((e) => { if (e[0].isIntersecting && !$("#mas").classList.contains("oculto")) cargarMas(); },
    { rootMargin: "600px" }).observe($("#mas"));
}

if (!token) mostrarLogin();
else cargarIndice().catch(() => {});
