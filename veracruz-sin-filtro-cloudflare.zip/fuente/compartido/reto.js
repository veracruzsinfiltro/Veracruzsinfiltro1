// Captcha invisible: resuelve el reto del servidor (prueba de trabajo SHA-256)
async function resolverReto(para) {
  const r = await fetch(`/api/reto?para=${para}`);
  if (!r.ok) throw new Error("reto");
  const { reto } = await r.json();
  const datos = JSON.parse(atob(reto.split(".")[0].replace(/-/g, "+").replace(/_/g, "/")));
  const sal = String(datos.sal), dif = Number(datos.dif);
  const cod = new TextEncoder();
  const ceros = (buf) => {
    let n = 0;
    for (const b of new Uint8Array(buf)) {
      if (b === 0) { n += 8; continue; }
      return n + Math.clz32(b) - 24;
    }
    return n;
  };
  const LOTE = 400;
  for (let base = 0; base < 5e7; base += LOTE) {
    const lote = [];
    for (let i = base; i < base + LOTE; i++) lote.push(crypto.subtle.digest("SHA-256", cod.encode(`${sal}:${i}`)));
    const res = await Promise.all(lote);
    for (let j = 0; j < res.length; j++) if (ceros(res[j]) >= dif) return { reto, nonce: String(base + j) };
  }
  throw new Error("reto");
}
