// Carga de fotos y videos por trozos.
// - Cola de 2 descargas a la vez: la página no se traba.
// - Las fotos se cargan al acercarse a la pantalla.
// - Los videos NO se descargan hasta que tocas "Ver video".
const COLA_MAX = 2;
let colaActivos = 0;
const colaPendiente = [];
function enCola(tarea) {
  return new Promise((ok, mal) => { colaPendiente.push({ tarea, ok, mal }); avanzarCola(); });
}
function avanzarCola() {
  while (colaActivos < COLA_MAX && colaPendiente.length) {
    const { tarea, ok, mal } = colaPendiente.shift();
    colaActivos++;
    tarea().then(ok, mal).finally(() => { colaActivos--; avanzarCola(); });
  }
}

const TIPOS_MEDIO = /^(image\/(jpeg|png|webp|gif)|video\/(mp4|webm|quicktime))$/;
const urlsMedio = new Map();

function descargarMedio(f, alAvanzar) {
  if (urlsMedio.has(f.clave)) return urlsMedio.get(f.clave);
  const pr = enCola(async () => {
    const partes = [];
    for (let i = 0; i < f.rutas.length; i++) {
      const r = await fetch(f.rutas[i], { headers: f.headers || {} });
      if (!r.ok) throw new Error("medio");
      partes.push(await r.blob());
      if (alAvanzar) alAvanzar((i + 1) / f.rutas.length);
    }
    return URL.createObjectURL(new Blob(partes, { type: f.tipo }));
  });
  urlsMedio.set(f.clave, pr);
  pr.catch(() => urlsMedio.delete(f.clave));
  return pr;
}

const tamTexto = (b) => (b / 1048576).toFixed(b < 10485760 ? 1 : 0) + " MB";

const obsMedios = "IntersectionObserver" in window
  ? new IntersectionObserver((ents) => {
      for (const e of ents) if (e.isIntersecting) { obsMedios.unobserve(e.target); e.target._cargar(); }
    }, { rootMargin: "400px" })
  : null;

// f = { clave, rutas: [...], tipo, tam, headers }
function cajaMedio(f) {
  const esVideo = f.tipo.startsWith("video/");
  const caja = el("div", { class: "m" + (esVideo ? " m-video" : "") });
  if (!TIPOS_MEDIO.test(f.tipo) || !f.rutas.length || f.rutas.length > 20) {
    caja.textContent = "Archivo no válido";
    return caja;
  }
  if (esVideo) {
    const etiqueta = el("span", { text: `Ver video · ${tamTexto(f.tam || 0)}` });
    const btn = el("button", { class: "play", type: "button" }, el("span", { class: "play-i", text: "▶" }), etiqueta);
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      try {
        const src = await descargarMedio(f, (p) => { etiqueta.textContent = `Cargando… ${Math.round(p * 100)}%`; });
        const v = el("video", { src, controls: "", playsinline: "", preload: "auto" });
        caja.replaceChildren(v);
        v.play().catch(() => {});
      } catch {
        btn.disabled = false;
        etiqueta.textContent = "No se pudo cargar · toca para reintentar";
      }
    });
    caja.append(btn);
    return caja;
  }
  caja.textContent = "Cargando foto…";
  caja._cargar = async () => {
    try {
      const src = await descargarMedio(f);
      caja.replaceChildren(el("img", { src, alt: "", decoding: "async" }));
    } catch { caja.textContent = "No se pudo cargar"; }
  };
  obsMedios ? obsMedios.observe(caja) : caja._cargar();
  return caja;
}

function hace(t) {
  const s = Math.floor((Date.now() - t) / 1000);
  if (s < 60) return "hace un momento";
  const m = Math.floor(s / 60); if (m < 60) return `hace ${m} min`;
  const h = Math.floor(m / 60); if (h < 24) return `hace ${h} h`;
  const d = Math.floor(h / 24); if (d < 7) return `hace ${d} d`;
  return new Date(t).toLocaleDateString("es-MX", { day: "numeric", month: "short", year: "numeric" });
}

// Tarjeta de chisme. fuenteDe(m) devuelve de dónde bajar cada archivo.
function tarjetaChisme(c, fuenteDe, extra) {
  const card = el("article", { class: "card chisme" },
    el("div", { class: "meta" },
      el("span", { class: "quien", text: c.nombre || "Anónimo" }),
      el("span", { text: "·" }),
      el("span", { text: hace(c.t) }),
    ),
  );
  if (c.texto) card.append(el("p", { class: "texto", text: c.texto }));
  if (c.medios && c.medios.length) {
    const g = el("div", { class: "galeria" + (c.medios.length === 1 ? " uno" : "") });
    c.medios.forEach((m) => g.append(cajaMedio(fuenteDe(m))));
    card.append(g);
  }
  if (extra) card.append(extra);
  return card;
}
