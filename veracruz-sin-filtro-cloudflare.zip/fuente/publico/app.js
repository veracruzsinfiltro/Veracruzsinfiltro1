const MAX_ARCHIVOS = 4;
const MAX_IMAGEN = 15 * 1024 * 1024;
const MAX_VIDEO = 60 * 1024 * 1024;
let seleccion = [];   // { file, url }
let tokenForm = null;
let retoListo = null; // promesa con el captcha resuelto

function prepararReto() {
  retoListo = resolverReto("chisme").catch(() => null);
}

async function pedirTokenForm() {
  try {
    const r = await fetch("/api/formulario");
    tokenForm = (await r.json()).token;
  } catch { tokenForm = null; }
}

const aviso = (t, tipo = "") => { const a = $("#aviso"); a.textContent = t; a.className = "aviso " + tipo; };
const progreso = (p) => {
  const b = $("#barra");
  b.style.display = p == null ? "none" : "block";
  b.firstElementChild.style.width = Math.round((p || 0) * 100) + "%";
};

async function actualizarContador() {
  try {
    const r = await fetch("/api/contador");
    const { total } = await r.json();
    const nodo = $("#contador");
    const ini = Number(nodo.textContent) || 0;
    const t0 = performance.now();
    const paso = (t) => {
      const k = Math.min(1, (t - t0) / 700);
      nodo.textContent = Math.round(ini + (total - ini) * k).toLocaleString("es-MX");
      if (k < 1) requestAnimationFrame(paso);
    };
    requestAnimationFrame(paso);
  } catch {}
}

// ----- Selección de archivos -----
function pintarPrevias() {
  const cont = $("#previas");
  cont.textContent = "";
  seleccion.forEach((s, i) => {
    const media = s.file.type.startsWith("video/")
      ? el("video", { src: s.url, muted: "", playsinline: "" })
      : el("img", { src: s.url, alt: "" });
    cont.append(el("div", { class: "previa" }, media,
      el("button", { type: "button", text: "×", "aria-label": "Quitar", onclick: () => {
        URL.revokeObjectURL(s.url); seleccion.splice(i, 1); pintarPrevias();
      } })));
  });
}

$("#archivos").addEventListener("change", (e) => {
  for (const f of e.target.files) {
    if (seleccion.length >= MAX_ARCHIVOS) { aviso(`Máximo ${MAX_ARCHIVOS} archivos`, "mal"); break; }
    const esVideo = f.type.startsWith("video/");
    if (!esVideo && !f.type.startsWith("image/")) { aviso("Solo fotos o videos", "mal"); continue; }
    if (f.size > (esVideo ? MAX_VIDEO : MAX_IMAGEN)) { aviso(`"${f.name}" es demasiado grande`, "mal"); continue; }
    seleccion.push({ file: f, url: URL.createObjectURL(f) });
  }
  e.target.value = "";
  pintarPrevias();
});

$("#texto").addEventListener("input", (e) => { $("#cuenta").textContent = e.target.value.length; });

// Re-dibuja la foto en un canvas: reduce tamaño y ELIMINA metadatos (GPS, cámara, etc.)
async function limpiarImagen(file) {
  if (file.type === "image/gif") return file; // se conserva la animación
  try {
    const bmp = await createImageBitmap(file, { imageOrientation: "from-image" });
    const max = 2000;
    const k = Math.min(1, max / Math.max(bmp.width, bmp.height));
    const c = document.createElement("canvas");
    c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
    c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
    const blob = await new Promise((r) => c.toBlob(r, "image/jpeg", 0.85));
    return blob || file;
  } catch {
    return file;
  }
}

function tipoVideo(f) {
  if (/^video\/(mp4|webm|quicktime)$/.test(f.type)) return f.type;
  if (/\.mov$/i.test(f.name)) return "video/quicktime";
  if (/\.webm$/i.test(f.name)) return "video/webm";
  return "video/mp4";
}

async function subirArchivo(file, tipo, alAvanzar) {
  const r = await fetch("/api/medio/iniciar", {
    method: "POST", headers: { "content-type": "application/json" },
    body: JSON.stringify({ tipo, tam: file.size, form: tokenForm }),
  });
  const ini = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(ini.error || "No se pudo subir el archivo");
  for (let i = 0; i < ini.trozos; i++) {
    const trozo = file.slice(i * ini.tamTrozo, (i + 1) * ini.tamTrozo);
    let ok = false;
    for (let intento = 0; intento < 3 && !ok; intento++) {
      const up = await fetch(`/api/medio/${ini.id}/${i}`, {
        method: "PUT", headers: { "x-token": ini.token, "content-type": "application/octet-stream" }, body: trozo,
      }).catch(() => null);
      ok = up && up.ok;
    }
    if (!ok) throw new Error("Falló la subida, revisa tu conexión");
    alAvanzar(Math.min(file.size, (i + 1) * ini.tamTrozo));
  }
  return ini.token;
}


$("#form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const nombre = $("#nombre").value.trim();
  const texto = $("#texto").value.trim();
  if (!texto && !seleccion.length) return aviso("Escribe algo o agrega una foto/video", "mal");

  const btn = $("#enviar");
  btn.disabled = true;
  aviso("Preparando…");
  try {
    if (!tokenForm) await pedirTokenForm();
    if (!retoListo) prepararReto();
    // Preparar archivos
    const listos = [];
    for (const s of seleccion) {
      if (s.file.type.startsWith("image/")) {
        const limpio = await limpiarImagen(s.file);
        listos.push({ blob: limpio, tipo: limpio.type || "image/jpeg" });
      } else {
        listos.push({ blob: s.file, tipo: tipoVideo(s.file) });
      }
    }
    const total = listos.reduce((a, x) => a + x.blob.size, 0) || 1;
    let hecho = 0;
    const tokens = [];
    if (listos.length) { progreso(0); aviso("Subiendo archivos…"); }
    for (const x of listos) {
      const base = hecho;
      tokens.push(await subirArchivo(x.blob, x.tipo, (n) => progreso((base + n) / total)));
      hecho += x.blob.size;
    }
    aviso("Verificando que eres humano…");
    let captcha = await retoListo;
    if (!captcha) { prepararReto(); captcha = await retoListo; }
    if (!captcha) throw new Error("No pudimos verificar que eres humano. Recarga la página.");
    retoListo = null;
    aviso("Enviando…");
    const r = await fetch("/api/chismes", {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ nombre, texto, medios: tokens, form: tokenForm, web: $("#web").value, reto: captcha.reto, nonce: captcha.nonce }),
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || "No se pudo enviar");

    $("#form").reset(); $("#cuenta").textContent = "0";
    seleccion.forEach((s) => URL.revokeObjectURL(s.url)); seleccion = []; pintarPrevias();
    aviso("¡Chisme recibido! 🤫 Gracias por el dato.", "ok");
    const nodo = $("#contador");
    nodo.textContent = ((parseInt(nodo.textContent.replace(/\D/g, ""), 10) || 0) + 1).toLocaleString("es-MX");
    pedirTokenForm();
    prepararReto();
  } catch (err) {
    retoListo = null;
    prepararReto();
    aviso(err.message, "mal");
  } finally {
    btn.disabled = false;
    progreso(null);
  }
});


// ---------- Muro público ----------
const muroEstado = { tipo: "todos", siguiente: 0, cargando: false, q: "", version: 0 };

function fuentePublica(c) {
  return (m) => ({
    clave: `p:${c.id}:${m.i}`,
    rutas: Array.from({ length: Math.min(m.trozos, 20) }, (_, j) => `/api/muro/medio/${c.id}/${m.i}/${j}`),
    tipo: m.tipo,
    tam: m.tam,
  });
}

function pintarMuro(items, limpiar) {
  const cont = $("#muro");
  if (limpiar) cont.textContent = "";
  for (const c of items) cont.append(tarjetaChisme(c, fuentePublica(c)));
  if (!cont.children.length) {
    cont.append(el("div", { class: "vacio", text: muroEstado.q ? "No encontramos chismes con esa palabra." : "Aún no hay chismes publicados aquí. ¡Manda el primero!" }));
  }
}

async function cargarMuro(reiniciar) {
  if (muroEstado.cargando && !reiniciar) return;
  const yo = ++muroEstado.version;
  if (reiniciar) { muroEstado.siguiente = 0; $("#muro").textContent = ""; }
  if (muroEstado.siguiente == null) return;
  muroEstado.cargando = true;
  $("#mas").disabled = true;
  try {
    let d;
    if (muroEstado.q.length >= 2) {
      const r = await fetch(`/api/muro/buscar?q=${encodeURIComponent(muroEstado.q)}`);
      d = await r.json();
      d.siguiente = null;
    } else {
      const r = await fetch(`/api/muro?tipo=${muroEstado.tipo}&desde=${muroEstado.siguiente}`);
      d = await r.json();
    }
    if (yo !== muroEstado.version) return;
    pintarMuro(Array.isArray(d.items) ? d.items : [], reiniciar);
    muroEstado.siguiente = d.siguiente ?? null;
  } catch {
    if (yo === muroEstado.version) $("#muro").append(el("div", { class: "vacio", text: "No se pudo cargar. Intenta de nuevo." }));
  } finally {
    if (yo === muroEstado.version) {
      muroEstado.cargando = false;
      $("#mas").disabled = false;
      $("#mas").classList.toggle("oculto", muroEstado.siguiente == null);
    }
  }
}

document.querySelectorAll("[data-tipo]").forEach((b) => b.addEventListener("click", () => {
  muroEstado.tipo = b.dataset.tipo;
  muroEstado.q = ""; $("#buscar").value = "";
  document.querySelectorAll("[data-tipo]").forEach((x) => x.classList.toggle("activo", x === b));
  cargarMuro(true);
}));
$("#mas").addEventListener("click", () => cargarMuro(false));
let tBusca = null;
$("#buscar").addEventListener("input", () => {
  clearTimeout(tBusca);
  tBusca = setTimeout(() => {
    muroEstado.q = $("#buscar").value.trim();
    cargarMuro(true);
  }, 500);
});
if ("IntersectionObserver" in window) {
  new IntersectionObserver((e) => {
    if (e[0].isIntersecting && !$("#mas").classList.contains("oculto") && !muroEstado.cargando) cargarMuro(false);
  }, { rootMargin: "600px" }).observe($("#mas"));
}

// ---------- Navegación entre vistas (#dejar, #muro) ----------
let muroCargado = false;
function mostrarVista() {
  const v = location.hash.replace("#", "");
  const vista = ["dejar", "muro"].includes(v) ? v : "inicio";
  for (const n of ["inicio", "dejar", "muro"]) $(`#v-${n}`).classList.toggle("oculto", n !== vista);
  if (vista === "dejar" && !tokenForm) pedirTokenForm();
  if (vista === "dejar" && !retoListo) prepararReto();
  if (vista === "muro" && !muroCargado) { muroCargado = true; cargarMuro(true); }
  window.scrollTo(0, 0);
}
window.addEventListener("hashchange", mostrarVista);
mostrarVista();
actualizarContador();
