// Cifrado y firmas con Web Crypto (Cloudflare Workers). Todo es asíncrono.
const SAL_ADMIN = "vsf-2026-admin::v2";
const HASH_ADMIN = "6111370b9028af280aed6531cb3bc4e06c711beb02b54c8fef53cea2ebd12c81";
const NULO = String.fromCharCode(0);

const cod = new TextEncoder();
const b64u = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const deB64u = (s) => Uint8Array.from(atob(s.replace(/-/g, "+").replace(/_/g, "/")), (c) => c.charCodeAt(0));
const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");

let _llaves = null;
async function llaves(env) {
  if (_llaves) return _llaves;
  const s = env.SECRETO;
  if (!s || s.length < 32) throw new Error("Falta SECRETO (minimo 32 caracteres)");
  const base = await crypto.subtle.importKey("raw", cod.encode(s), "HKDF", false, ["deriveBits"]);
  const der = async (info) => new Uint8Array(await crypto.subtle.deriveBits(
    { name: "HKDF", hash: "SHA-256", salt: cod.encode("vsf-v2"), info: cod.encode(info) }, base, 256));
  const cifrado = await crypto.subtle.importKey("raw", await der("cifrado"), "AES-GCM", false, ["encrypt", "decrypt"]);
  const firma = await crypto.subtle.importKey("raw", await der("firma"), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const huellaK = await crypto.subtle.importKey("raw", await der("huella"), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  _llaves = { cifrado, firma, huella: huellaK };
  return _llaves;
}

export async function cifrar(env, datos, contexto = "") {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const k = (await llaves(env)).cifrado;
  const buf = datos instanceof Uint8Array ? datos : new Uint8Array(datos);
  const enc = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv, additionalData: cod.encode(contexto) }, k, buf));
  const out = new Uint8Array(12 + enc.length);
  out.set(iv, 0); out.set(enc, 12);
  return out;
}
export async function descifrar(env, datos, contexto = "") {
  const buf = new Uint8Array(datos);
  if (buf.length < 28) throw new Error("dato corrupto");
  const k = (await llaves(env)).cifrado;
  const dec = await crypto.subtle.decrypt({ name: "AES-GCM", iv: buf.subarray(0, 12), additionalData: cod.encode(contexto) }, k, buf.subarray(12));
  return new Uint8Array(dec);
}
export const cifrarJSON = (env, obj, ctx) => cifrar(env, cod.encode(JSON.stringify(obj)), ctx);
export const descifrarJSON = async (env, buf, ctx) => JSON.parse(new TextDecoder().decode(await descifrar(env, buf, ctx)));

async function firmar(env, texto) {
  const sig = await crypto.subtle.sign("HMAC", (await llaves(env)).firma, cod.encode(texto));
  return b64u(sig);
}
function igual(a, b) {
  const x = cod.encode(String(a)), y = cod.encode(String(b));
  if (x.length !== y.length) return false;
  let d = 0; for (let i = 0; i < x.length; i++) d |= x[i] ^ y[i];
  return d === 0;
}

export async function crearToken(env, uso, datos, minutos) {
  const cuerpo = b64u(cod.encode(JSON.stringify({ ...datos, uso, exp: Date.now() + minutos * 60000 })));
  return cuerpo + "." + await firmar(env, cuerpo);
}
export async function leerToken(env, token, uso) {
  if (typeof token !== "string" || token.length > 2000) return null;
  const partes = token.split(".");
  if (partes.length !== 2 || !igual(partes[1], await firmar(env, partes[0]))) return null;
  try {
    const d = JSON.parse(new TextDecoder().decode(deB64u(partes[0])));
    if (d.uso !== uso || typeof d.exp !== "number" || Date.now() > d.exp) return null;
    return d;
  } catch { return null; }
}

export async function credencialesValidas(env, usuario, clave) {
  if (typeof usuario !== "string" || typeof clave !== "string") return false;
  if (usuario.length > 100 || clave.length > 200) return false;
  const base = await crypto.subtle.importKey("raw", cod.encode(usuario + NULO + clave), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: cod.encode(SAL_ADMIN), iterations: 600000 }, base, 256);
  return igual(hex(bits), HASH_ADMIN);
}

export async function huella(env, texto) {
  const sig = await crypto.subtle.sign("HMAC", (await llaves(env)).huella, cod.encode("rl|" + texto));
  return hex(sig).slice(0, 32);
}

export const aleatorio = (n) => hex(crypto.getRandomValues(new Uint8Array(n)));

// Captcha invisible (prueba de trabajo)
export const crearReto = (env, para, dif) => crearToken(env, "reto", { para, sal: aleatorio(12), dif }, 5);
export async function retoValido(env, token, nonce, para) {
  const t = await leerToken(env, token, "reto");
  if (!t || t.para !== para || !Number.isInteger(t.dif)) return null;
  if (typeof nonce !== "string" || !/^\d{1,12}$/.test(nonce)) return null;
  const h = new Uint8Array(await crypto.subtle.digest("SHA-256", cod.encode(`${t.sal}:${nonce}`)));
  let bits = 0;
  for (const b of h) { if (b === 0) { bits += 8; continue; } bits += Math.clz32(b) - 24; break; }
  return bits >= t.dif ? t : null;
}
