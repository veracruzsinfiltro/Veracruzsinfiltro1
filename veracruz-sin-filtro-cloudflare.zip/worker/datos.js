// Almacenamiento sobre un bucket R2. Cada "store" es un prefijo dentro del bucket.
// Se mantiene la misma interfaz que antes (get/set/delete/getMetadata/list) para
// reutilizar la lógica de rutas casi sin cambios.
function store(bucket, nombre) {
  const pre = nombre + "/";
  return {
    async get(k, o = {}) {
      const obj = await bucket.get(pre + k);
      if (!obj) return null;
      if (o.type === "arrayBuffer") return await obj.arrayBuffer();
      return await obj.text();
    },
    async getMetadata(k) {
      const h = await bucket.head(pre + k);
      return h ? { metadata: {} } : null;
    },
    async set(k, v) {
      await bucket.put(pre + k, v);
    },
    async delete(k) {
      await bucket.delete(pre + k);
    },
    // Devuelve las llaves SIN el prefijo del store (como antes)
    async listar(subprefijo) {
      const out = [];
      let cursor;
      do {
        const r = await bucket.list({ prefix: pre + (subprefijo || ""), cursor, limit: 1000 });
        for (const o of r.objects) out.push(o.key.slice(pre.length));
        cursor = r.truncated ? r.cursor : null;
      } while (cursor);
      return out;
    },
  };
}

export function tiendas(env) {
  const b = env.BUCKET;
  return {
    chismes: store(b, "chismes"),
    medios: store(b, "medios"),
    estados: store(b, "estados"),
    muro: store(b, "muro"),
    limites: store(b, "limites"),
  };
}

export const esLlave = (k) => typeof k === "string" && /^\d{13}-[a-f0-9]{12}(-[0-4][0-4][01])?$/.test(k);
export const esLlaveNueva = (k) => typeof k === "string" && /^\d{13}-[a-f0-9]{12}-[0-4][0-4][01]$/.test(k);
export const horaDeLlave = (k) => 9999999999999 - parseInt(k.slice(0, 13), 10);
export const banderas = (k) => { const b = k.split("-")[2] || "000"; return { f: +b[0], v: +b[1], n: +b[2] }; };
export const esIdMedio = (k) => typeof k === "string" && /^[a-f0-9]{32}$/.test(k);
export const horaDeMedio = (id) => parseInt(id.slice(0, 12), 16);

export async function borrarMedio(T, id) {
  for (const k of await T.medios.listar(`${id}/`)) await T.medios.delete(k);
  await T.estados.delete(`u-${id}`);
}

// Limpieza (corre por Cron cada hora). Segura: nunca toca archivos antiguos ni recientes.
export async function limpiar(T) {
  const ahora = Date.now();
  let borrados = 0;
  for (const k of await T.limites.listar()) {
    if (!(parseInt(k.split("-")[0], 10) > ahora)) { await T.limites.delete(k); borrados++; }
  }
  for (const pre of ["c-", "r-"]) {
    for (const k of await T.estados.listar(pre)) {
      if (!(parseInt(k.split("-")[1], 10) > ahora)) { await T.estados.delete(k); borrados++; }
    }
  }
  const usados = new Set((await T.estados.listar("u-")).map((k) => k.slice(2)));
  if (!usados.size && (await T.chismes.listar()).length) return borrados;
  const DESDE = Date.UTC(2026, 0, 1);
  const ids = new Set((await T.medios.listar()).map((k) => k.split("/")[0]));
  for (const id of ids) {
    if (!esIdMedio(id)) continue;
    const hora = horaDeMedio(id);
    if (hora > DESDE && hora < ahora && ahora - hora > 6 * 3600000 && !usados.has(id)) {
      for (const k of await T.medios.listar(`${id}/`)) { await T.medios.delete(k); borrados++; }
    }
  }
  return borrados;
}
