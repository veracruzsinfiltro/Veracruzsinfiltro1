# Veracruz sin filtro — versión Cloudflare

Buzón de chismes anónimos con muro de aprobación. Ahora corre en **Cloudflare Workers + R2**
(el tráfico de videos NO cuesta, a diferencia de Netlify).

## Qué es cada carpeta
- `fuente/` → código legible de la página y el panel (edita aquí).
- `public/` → lo que se sirve como archivos (HTML + JS/CSS minificados). Generado.
- `worker/` → el servidor de Cloudflare (API, panel, seguridad, base de datos). Generado en parte.
- `wrangler.toml` → configuración de Cloudflare.
- Tras editar `fuente/`, regenera con: `npm run construir`.

## Instalar (una sola vez)
1. Crea cuenta en https://dash.cloudflare.com (o usa la que quieras).
2. En tu compu: instala Node y luego `npm install` dentro de la carpeta.
3. Inicia sesión en Cloudflare: `npx wrangler login`.

## Crear la base de datos (R2)
1. En el panel de Cloudflare: **R2 → Create bucket**.
2. Nombre exacto: **veracruz-sin-filtro** (igual que en `wrangler.toml`).
   - R2 puede pedirte agregar una tarjeta aunque el uso sea gratis (10 GB y salida gratis).

## Poner la variable SECRETO
Es la llave que cifra todo. Ponla como **secreto** (no como variable normal):

    npx wrangler secret put SECRETO

y pega cuando lo pida:

    V_XBFVDTGr62wdYmI9PmKl2TGj8eKnB0_Pa54Al4Ypk

- También puedes ponerla en el panel: **Workers & Pages → tu worker → Settings → Variables and Secrets → Add → tipo Secret**, nombre `SECRETO`.
- **No la cambies nunca** o no se podrán leer los chismes. No la subas a GitHub.

## Subir el sitio
    npm run deploy

(equivale a `npm run construir` y luego `npx wrangler deploy`).
Al terminar te da una URL tipo `veracruz-sin-filtro.TU-USUARIO.workers.dev`.

## Poner tu dominio .site
1. Panel de Cloudflare → **Add a site** → escribe `veracruzsinfiltro.site` → plan Free.
2. Cloudflare te da 2 **nameservers**. Cópialos en Hostinger (igual que hiciste con Netlify):
   Hostinger → tu dominio → DNS / Nameservers → usar personalizados → pega los de Cloudflare.
3. Cuando el dominio ya esté "Active" en Cloudflare:
   **Workers & Pages → tu worker → Settings → Domains & Routes → Add → Custom domain**
   y escribe `veracruzsinfiltro.site` (y también `www.veracruzsinfiltro.site` si lo quieres).
   El HTTPS se activa solo.

## Direcciones
- Página: `https://veracruzsinfiltro.site`
- Panel:  `https://veracruzsinfiltro.site/23$$`  (usuario y contraseña de siempre)

## Notas
- Los chismes que tenías en Netlify NO se pasan: la base de R2 empieza vacía. Los nuevos se guardan aquí.
- La limpieza de archivos abandonados corre sola cada hora (Cron Trigger, ya configurado).
- Todo sigue cifrado, con captcha invisible, ruta de panel secreta y respuestas de burla a quien lo intente.
