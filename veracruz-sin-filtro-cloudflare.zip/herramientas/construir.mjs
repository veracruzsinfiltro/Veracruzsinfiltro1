// Genera los archivos publicados a partir de /fuente:
//   - public/index.html, public/js/<hash>.js, public/css/<hash>.css  (minificados)
//   - netlify/privado/generado.mjs  (pantalla de acceso y código del panel, NO públicos)
// Uso:  node herramientas/construir.mjs     (necesita esbuild: npx esbuild o ESBUILD_BIN)
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";

const raiz = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const F = (...p) => path.join(raiz, "fuente", ...p);
const leer = (p) => fs.readFileSync(p, "utf8");
const BIN = process.env.ESBUILD_BIN || "esbuild";

function esbuild(codigo, loader) {
  return execFileSync(BIN, [`--loader=${loader}`, "--minify", "--legal-comments=none", "--charset=utf8", "--target=es2020"], {
    input: codigo, encoding: "utf8",
  }).trim();
}
const hash = (s) => createHash("sha256").update(s).digest("hex").slice(0, 16);
const html = (s) => s.replace(/<!--[\s\S]*?-->/g, "").replace(/\n\s*/g, "").trim();
const envolver = (...partes) => `(()=>{"use strict";\n${partes.join("\n;\n")}\n})();`;

// Política de seguridad (misma para archivos y funciones)
const CSP = [
  "default-src 'none'", "script-src 'self'", "style-src 'self'", "font-src 'self'",
  "img-src 'self' blob: data:", "media-src blob:", "connect-src 'self'",
  "form-action 'none'", "base-uri 'none'", "frame-ancestors 'none'", "object-src 'none'",
  "upgrade-insecure-requests",
].join("; ");

// Limpia generados anteriores
for (const d of ["js", "css"]) fs.rmSync(path.join(raiz, "public", d), { recursive: true, force: true });
fs.mkdirSync(path.join(raiz, "public", "js"), { recursive: true });
fs.mkdirSync(path.join(raiz, "public", "css"), { recursive: true });

// CSS
const css = esbuild(leer(F("estilos.css")), "css");
const rutaCss = `/css/${hash(css)}.css`;
fs.writeFileSync(path.join(raiz, "public", rutaCss), css);

// Página pública
const medios = leer(F("compartido", "medios.js"));
const reto = leer(F("compartido", "reto.js"));
const app = esbuild(envolver(leer(F("publico", "base.js")), medios, reto, leer(F("publico", "app.js"))), "js");
const rutaApp = `/js/${hash(app)}.js`;
fs.writeFileSync(path.join(raiz, "public", rutaApp), app);
fs.writeFileSync(path.join(raiz, "public", "index.html"),
  html(leer(F("publico", "index.html")).replace("__CSS__", rutaCss).replace("__JS__", rutaApp)));

// Panel (privado)
const marcado = html(leer(F("panel", "marcado.html")));
const panel = esbuild(envolver(
  `document.body.insertAdjacentHTML("beforeend", ${JSON.stringify(marcado)});`,
  leer(F("panel", "comun.js")), medios, leer(F("panel", "panel.js")), leer(F("panel", "historia.js")),
), "js");
const login = esbuild(envolver(reto, leer(F("panel", "login.js"))), "js");
const loginHtml = html(leer(F("panel", "login.html")).replace("__CSS__", rutaCss).replace("__LOGIN__", () => "/23$$/i.js"));

const generado = "// ARCHIVO GENERADO por herramientas/construir.mjs — no editar a mano\n" +
  `export const CSP = ${JSON.stringify(CSP)};\n` +
  `export const LOGIN_HTML = ${JSON.stringify(loginHtml)};\n` +
  `export const LOGIN_JS = ${JSON.stringify(login)};\n` +
  `export const PANEL_JS = ${JSON.stringify(panel)};\n`;
fs.writeFileSync(path.join(raiz, "worker", "generado.js"), generado);

console.log("Listo:", rutaCss, rutaApp, `panel ${panel.length} bytes`);
